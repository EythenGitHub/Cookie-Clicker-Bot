import pyautogui
import time
import keyboard
import sys
import random

while True:
    if keyboard.is_pressed('f'):
        sys.exit()
    # time.sleep(0)
    pyautogui.tripleClick(50, 500)
    cColor = pyautogui.pixel(775, 443)
    print()
    gColor = pyautogui.pixel(767, 525)
    print()
    uColor = pyautogui.pixel(584, 326)
    print()

    if pyautogui.pixel(775, 443) == cColor:
        print("")
    else:
        time.sleep(0)
        pyautogui.click(775, 443)
        #break

    if pyautogui.pixel(767, 525) == gColor:
        print("")
    else:
        time.sleep(0)
        pyautogui.click(767, 525)

    if pyautogui.pixel(584, 326) == uColor:
        print("")
    else:
        time.sleep(0)
        pyautogui.click(584, 326)

#       if random.randint(0, 10) == 2: #upgrade cursor
#         pyautogui.click(730, 431)
#     if random.randint(0, 10) == 4: #upgrade grandma
#         pyautogui.click(615, 301)
#     if random.randint(0, 10) == 5:  # upgrade store
#         pyautogui.click(754, 513)